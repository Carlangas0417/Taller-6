package uniandes.dpoo.swing.interfaz.agregar;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import uniandes.dpoo.swing.interfaz.principal.VentanaPrincipal;

@SuppressWarnings("serial")
public class VentanaAgregarRestaurante extends JFrame
{
    private PanelEditarRestaurante panelDetalles;
    private PanelBotonesAgregar panelBotones;
    private PanelMapaAgregar panelMapa;
    private VentanaPrincipal ventanaPrincipal;

    public VentanaAgregarRestaurante( VentanaPrincipal principal )
    {
        this.ventanaPrincipal = principal;
        setLayout( new BorderLayout() );

        panelMapa = new PanelMapaAgregar();
        add( panelMapa, BorderLayout.CENTER );

        panelDetalles = new PanelEditarRestaurante();
        panelBotones = new PanelBotonesAgregar( this );
        JPanel sur = new JPanel( new BorderLayout() );
        sur.add( panelDetalles, BorderLayout.CENTER );
        sur.add( panelBotones, BorderLayout.SOUTH );
        add( sur, BorderLayout.SOUTH );

        pack();
        setLocationRelativeTo( null );
        setDefaultCloseOperation( DISPOSE_ON_CLOSE );
        setResizable( false );
    }

    public void agregarRestaurante()
    {
        String nombre = panelDetalles.getNombre();
        int calif   = panelDetalles.getCalificacion();
        boolean vis = panelDetalles.getVisitado();
        int[]  xy   = panelMapa.getCoordenadas();
        ventanaPrincipal.agregarRestaurante( nombre, calif, xy[0], xy[1], vis );
        cerrarVentana();
    }

    public void cerrarVentana()
    {
        dispose();
    }
}

package uniandes.dpoo.swing.interfaz.mapa;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import uniandes.dpoo.swing.interfaz.principal.VentanaPrincipal;
import uniandes.dpoo.swing.mundo.Restaurante;

@SuppressWarnings("serial")
public class VentanaMapa extends JFrame implements ActionListener
{
    private static final String VISITADOS = "VISITADOS";
    private static final String TODOS      = "TODOS";

    private PanelMapaVisualizar panelMapa;
    private JRadioButton radioTodos;
    private JRadioButton radioVisitados;
    private VentanaPrincipal ventanaPrincipal;

    public VentanaMapa( VentanaPrincipal ventanaPrincipal, List<Restaurante> restaurantes )
    {
        this.ventanaPrincipal = ventanaPrincipal;
        setLayout( new BorderLayout() );

        panelMapa = new PanelMapaVisualizar();
        add( panelMapa, BorderLayout.CENTER );
        panelMapa.actualizarMapa( restaurantes );

        JPanel opciones = new JPanel( new FlowLayout() );
        radioTodos = new JRadioButton( "Todos" );
        radioTodos.setActionCommand( TODOS );
        radioTodos.addActionListener( this );
        radioVisitados = new JRadioButton( "Visitados" );
        radioVisitados.setActionCommand( VISITADOS );
        radioVisitados.addActionListener( this );
        ButtonGroup bg = new ButtonGroup();
        bg.add( radioTodos );
        bg.add( radioVisitados );
        radioTodos.setSelected( true );
        opciones.add( radioTodos );
        opciones.add( radioVisitados );
        add( opciones, BorderLayout.SOUTH );

        pack();
        setResizable( false );
        setDefaultCloseOperation( DISPOSE_ON_CLOSE );
        setLocationRelativeTo( null );
    }

    @Override
    public void actionPerformed( ActionEvent e )
    {
        String cmd = e.getActionCommand();
        if( TODOS.equals( cmd ) )
            panelMapa.actualizarMapa( ventanaPrincipal.getRestaurantes( true ) );
        else if( VISITADOS.equals( cmd ) )
            panelMapa.actualizarMapa( ventanaPrincipal.getRestaurantes( false ) );
    }
}
